config = {
 	vfs_prefix: "managed",
 	deploy_prefix: "managed",
 	enable_debugging: 0,
 	file_list: [ "UnoBrotli.Wasm.dll","mscorlib.dll","System.dll","Mono.Security.dll","System.Xml.dll","System.Numerics.dll","System.Core.dll","WebAssembly.Net.WebSockets.dll","WebAssembly.Bindings.dll","System.Drawing.Common.dll","System.Net.Http.dll","System.Net.Http.WebAssemblyHttpHandler.dll","Uno.UI.dll","Uno.Xaml.dll","Uno.Foundation.dll","Microsoft.Extensions.Logging.Abstractions.dll","Uno.Core.dll","System.Collections.Immutable.dll","CommonServiceLocator.dll","Microsoft.Extensions.Logging.dll","Uno.dll","Microsoft.Extensions.Logging.Filter.dll","Microsoft.Extensions.Logging.Console.dll","Uno.UI.Toolkit.dll","Uno.UI.Wasm.dll" ],
}
